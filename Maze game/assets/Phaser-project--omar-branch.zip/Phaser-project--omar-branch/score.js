let score = 0;
let scoreText;